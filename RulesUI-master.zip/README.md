# RulesUI
This plugin adds the command /rules with this command you can see in a UI the rules everything is changeable via config.
